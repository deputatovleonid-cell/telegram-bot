"use client";

import { useState, useEffect } from "react";
import {
  motion,
  useScroll,
  useTransform,
  AnimatePresence,
} from "motion/react";
import { Button } from "./components/ui/button";
import { Card } from "./components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogTrigger,
} from "./components/ui/dialog";
import { Input } from "./components/ui/input";
import { Textarea } from "./components/ui/textarea";
import {
  Video,
  Edit3,
  FileText,
  Clapperboard,
  Play,
  Instagram,
  Twitter,
  Linkedin,
  Mail,
  Phone,
  Lightbulb,
  Clock,
  Award,
  Zap,
  Eye,
  CheckCircle,
  MessageCircle,
  Bot,
} from "lucide-react";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";
import logo from "figma:asset/da55e2ec4430b9f6c09ea7788e8ba0735b3e0241.png";

const services = [
  {
    id: "videography",
    title: "Mobile Videography",
    icon: Video,
    emoji: "🎥",
    description:
      "Stylish on-location shots with cinematic framing",
    fullDescription:
      "Professional mobile filming with smartphone rigs, creative lighting setups under violet-blue LEDs, and cinematic angles that rival traditional camera work.",
    features: [
      "4K Mobile Recording",
      "Creative LED Lighting",
      "Cinematic Angles",
      "On-Location Shooting",
    ],
    backgroundImage:
      "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=1200&h=800&fit=crop",
    portfolioItems: [
      "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1536240478700-b869070f9279?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1533747409543-9571a0b6e93b?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=600&fit=crop",
    ],
  },
  {
    id: "scriptwriting",
    title: "Creative Scriptwriting",
    icon: FileText,
    emoji: "✍️",
    description:
      "Dynamic storyboard sketches and compelling narratives",
    fullDescription:
      "Hand-crafted scripts with detailed storyboard sketches, compelling narratives that capture your brand voice and convert viewers into customers.",
    features: [
      "Storyboard Creation",
      "Brand Voice Development",
      "Script Optimization",
      "Narrative Design",
    ],
    backgroundImage:
      "https://images.unsplash.com/photo-1455390582262-044cdead277a?w=1200&h=800&fit=crop",
    portfolioItems: [
      "https://images.unsplash.com/photo-1455390582262-044cdead277a?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1542435503-956c469947f6?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1434626881859-194d67b2b86f?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1471107340929-a87cd0f5b5f3?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1488190211105-8b0e65b80b4e?w=800&h=600&fit=crop",
    ],
  },
  {
    id: "editing",
    title: "Video Editing",
    icon: Edit3,
    emoji: "🎬",
    description:
      "Professional editing with smooth cuts and VFX",
    fullDescription:
      "Advanced video editing with cinematic color grading in cool violet-blue hues, motion graphics, smooth transitions, and visual effects that transform raw footage into compelling stories.",
    features: [
      "Color Grading",
      "Motion Graphics",
      "Sound Design",
      "VFX & Transitions",
    ],
    backgroundImage:
      "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=1200&h=800&fit=crop",
    portfolioItems: [
      "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1551434678-e076c223a692?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&h=600&fit=crop",
    ],
  },
  {
    id: "production",
    title: "Full Production",
    icon: Clapperboard,
    emoji: "🚀",
    description:
      "Complete video production with professional talent",
    fullDescription:
      "End-to-end video production with professional talent casting, cinematic set design with purple-blue light accents, full crew, and artistic direction for maximum impact.",
    features: [
      "Talent Casting",
      "Set Design",
      "Full Crew",
      "Cinematic Direction",
    ],
    backgroundImage:
      "https://images.unsplash.com/photo-1533747409543-9571a0b6e93b?w=1200&h=800&fit=crop",
    portfolioItems: [
      "https://images.unsplash.com/photo-1533747409543-9571a0b6e93b?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1485095329183-d0797cdc5676?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1472289065668-ce650ac443d2?w=800&h=600&fit=crop",
    ],
  },
];

const whyChooseUs = [
  {
    icon: Lightbulb,
    title: "Bold Visual Ideas",
    description:
      "We transform creative concepts into stunning visual stories that captivate your audience",
  },
  {
    icon: Clock,
    title: "Fast Turnaround",
    description:
      "Quick delivery without compromising quality. Most projects completed within 5-7 days",
  },
  {
    icon: Award,
    title: "Premium Quality at Fair Price",
    description:
      "Professional-grade production at prices that won't break your budget",
  },
  {
    icon: Zap,
    title: "Full Cycle Production",
    description:
      "Complete end-to-end service from initial concept to polished, ready-to-publish content",
  },
];

const MovingLightSpot = ({
  className,
  delay = 0,
}: {
  className: string;
  delay?: number;
}) => (
  <motion.div
    className={`absolute rounded-full blur-xl opacity-15 ${className}`}
    animate={{
      x: [0, 50, 0, -30, 0],
      y: [0, -30, 50, 0, -20, 0],
      scale: [1, 1.2, 0.8, 1.1, 1],
    }}
    transition={{
      duration: 15,
      repeat: Infinity,
      delay,
      ease: "easeInOut",
    }}
  />
);

const FloatingParticle = ({
  className,
  delay = 0,
}: {
  className: string;
  delay?: number;
}) => (
  <motion.div
    className={`absolute opacity-20 ${className}`}
    animate={{
      y: [0, -30, 0],
      x: [0, 15, 0],
      rotate: [0, 10, 0],
      scale: [1, 1.1, 1],
    }}
    transition={{
      duration: 8,
      repeat: Infinity,
      delay,
      ease: "easeInOut",
    }}
  />
);

const AIAssistant = () => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <motion.div
      className="fixed bottom-6 right-6 z-50"
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      transition={{ delay: 2, duration: 0.5 }}
    >
      <motion.div
        className="relative"
        onHoverStart={() => setIsExpanded(true)}
        onHoverEnd={() => setIsExpanded(false)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        {/* Expanded Panel */}
        <AnimatePresence>
          {isExpanded && (
            <motion.div
              className="absolute bottom-16 right-0 bg-white rounded-2xl shadow-2xl p-4 min-w-64 border-2"
              style={{
                background:
                  "linear-gradient(135deg, rgba(58, 12, 163, 0.05) 0%, rgba(67, 97, 238, 0.05) 100%)",
                borderImage:
                  "linear-gradient(135deg, #7209B7, #4895EF) 1",
              }}
              initial={{ opacity: 0, y: 20, scale: 0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.8 }}
              transition={{ duration: 0.2 }}
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#3A0CA3] to-[#4361EE] flex items-center justify-center">
                  <Bot className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="font-semibold text-[#1A1B2E]">
                    AWES0ME AI
                  </p>
                  <p className="text-sm text-gray-600">
                    Ask me anything!
                  </p>
                </div>
              </div>
              <p className="text-sm text-gray-700 mb-3">
                Hi! I'm here to help you plan your video
                project. What can I help you with?
              </p>
              <Button
                size="sm"
                className="w-full bg-gradient-to-r from-[#3A0CA3] to-[#4361EE] hover:from-[#3A0CA3]/90 hover:to-[#4361EE]/90 text-white"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Start Chat
              </Button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Button */}
        <motion.button
          className="w-16 h-16 rounded-full shadow-lg flex items-center justify-center relative overflow-hidden"
          style={{
            background:
              "linear-gradient(135deg, #3A0CA3 0%, #4361EE 100%)",
          }}
          animate={{
            boxShadow: [
              "0 4px 15px rgba(58, 12, 163, 0.3)",
              "0 8px 25px rgba(67, 97, 238, 0.4)",
              "0 4px 15px rgba(58, 12, 163, 0.3)",
            ],
          }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <motion.div
            className="absolute inset-0 rounded-full"
            style={{
              background:
                "linear-gradient(135deg, rgba(255, 255, 255, 0.1) 0%, rgba(255, 255, 255, 0.05) 100%)",
            }}
            animate={{
              scale: [1, 1.1, 1],
              opacity: [0.5, 0.8, 0.5],
            }}
            transition={{ duration: 2, repeat: Infinity }}
          />
          <img
            src={logo}
            alt="AI Assistant"
            className="w-8 h-8 relative z-10"
          />
          <motion.div
            className="absolute bottom-1 right-1 w-3 h-3 bg-white rounded-full"
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.8, 1, 0.8],
            }}
            transition={{ duration: 1, repeat: Infinity }}
          />
        </motion.button>
      </motion.div>
    </motion.div>
  );
};

export default function App() {
  const [selectedService, setSelectedService] = useState<
    string | null
  >(null);
  const { scrollYProgress } = useScroll();
  const heroY = useTransform(
    scrollYProgress,
    [0, 1],
    ["0%", "50%"],
  );
  const heroOpacity = useTransform(
    scrollYProgress,
    [0, 0.3],
    [1, 0],
  );

  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      {/* AI Assistant */}
      <AIAssistant />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Violet-Blue Gradient Background */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse at center, #3A0CA3 0%, #4361EE 50%, #7209B7 100%)",
          }}
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(135deg, rgba(255, 255, 255, 0.1) 0%, rgba(255, 255, 255, 0.05) 50%, transparent 100%)",
          }}
        />

        {/* Animated Waves */}
        <motion.div
          className="absolute inset-0 opacity-30"
          animate={{
            background: [
              "radial-gradient(circle at 20% 20%, rgba(114, 9, 183, 0.4) 0%, transparent 50%)",
              "radial-gradient(circle at 80% 80%, rgba(72, 149, 239, 0.4) 0%, transparent 50%)",
              "radial-gradient(circle at 20% 20%, rgba(114, 9, 183, 0.4) 0%, transparent 50%)",
            ],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />

        {/* Moving Light Spots */}
        <MovingLightSpot
          className="w-96 h-96 bg-white/20 top-10 left-10"
          delay={0}
        />
        <MovingLightSpot
          className="w-64 h-64 bg-[#4895EF]/30 top-1/3 right-20"
          delay={2}
        />
        <MovingLightSpot
          className="w-80 h-80 bg-white/15 bottom-20 left-1/4"
          delay={4}
        />
        <MovingLightSpot
          className="w-72 h-72 bg-[#7209B7]/25 bottom-1/3 right-10"
          delay={6}
        />

        {/* Floating Particles */}
        <FloatingParticle
          className="w-3 h-3 bg-white rounded-full top-20 left-1/4"
          delay={0}
        />
        <FloatingParticle
          className="w-2 h-2 bg-[#4895EF] rounded-full top-1/3 right-1/4"
          delay={1}
        />
        <FloatingParticle
          className="w-4 h-4 bg-white/50 rounded-full bottom-1/3 left-1/3"
          delay={2}
        />
        <FloatingParticle
          className="w-3 h-3 bg-[#7209B7]/70 rounded-full bottom-1/4 right-1/3"
          delay={3}
        />

        <motion.div
          className="text-center z-10 px-4 max-w-5xl mx-auto"
          style={{ y: heroY, opacity: heroOpacity }}
        >
          {/* Logo with Enhanced Animation */}
          <motion.div
            className="mb-12 flex justify-center"
            initial={{ scale: 0.3, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1.5, ease: "easeOut" }}
          >
            <motion.div
              className="relative"
              whileHover={{ scale: 1.08, rotate: 2 }}
              animate={{
                filter: [
                  "drop-shadow(0 0 20px rgba(255, 255, 255, 0.6))",
                  "drop-shadow(0 0 40px rgba(255, 255, 255, 0.8))",
                  "drop-shadow(0 0 20px rgba(255, 255, 255, 0.6))",
                ],
              }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              <motion.div
                className="absolute -inset-4 rounded-2xl border-2 border-white/40"
                animate={{
                  scale: [1, 1.1, 1],
                  opacity: [0.3, 0.7, 0.3],
                  rotate: [0, 2, 0],
                }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              <img
                src={logo}
                alt="AWES0ME AGENCY"
                className="w-48 h-48 md:w-56 md:h-56 relative z-10 rounded-2xl"
              />
            </motion.div>
          </motion.div>

          {/* Main Headline */}
          <motion.h1
            className="text-5xl md:text-7xl lg:text-8xl text-white mb-6 leading-tight font-bold"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            From Idea to Impact
          </motion.h1>

          {/* Subline */}
          <motion.p
            className="text-2xl md:text-3xl text-white/90 mb-4 font-medium"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.7, duration: 0.8 }}
          >
            Mobile Filming • Editing • Creative Scripts
          </motion.p>

          <motion.p
            className="text-xl md:text-2xl text-white/80 mb-16 max-w-3xl mx-auto"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.9, duration: 0.8 }}
          >
            We turn bold ideas into visually stunning ads that
            captivate and convert
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-16"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 1.1, duration: 0.8 }}
          >
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button
                size="lg"
                className="bg-white text-[#3A0CA3] hover:bg-white/90 px-8 py-4 text-lg font-semibold rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
                onClick={() =>
                  document
                    .getElementById("services")
                    ?.scrollIntoView({ behavior: "smooth" })
                }
              >
                Choose a Service
              </Button>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button
                size="lg"
                variant="outline"
                className="border-2 border-white text-white hover:bg-white hover:text-[#3A0CA3] px-8 py-4 text-lg font-semibold rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
                onClick={() =>
                  document
                    .getElementById("portfolio")
                    ?.scrollIntoView({ behavior: "smooth" })
                }
              >
                <Play className="w-5 h-5 mr-2" />
                View Portfolio
              </Button>
            </motion.div>
          </motion.div>

          {/* Service Quick Access */}
          <motion.div
            className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 1.3, duration: 0.8 }}
          >
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <motion.div
                  key={service.id}
                  whileHover={{ scale: 1.05, y: -5 }}
                  whileTap={{ scale: 0.95 }}
                  initial={{ y: 30, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 1.4 + index * 0.1 }}
                >
                  <Button
                    variant="outline"
                    className="w-full h-20 bg-white/10 backdrop-blur-sm border-2 border-white/30 hover:border-white hover:bg-white/20 transition-all duration-300 flex-col gap-1 text-white hover:text-white"
                    onClick={() => {
                      document
                        .getElementById("services")
                        ?.scrollIntoView({
                          behavior: "smooth",
                        });
                      setTimeout(
                        () => setSelectedService(service.id),
                        500,
                      );
                    }}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="text-xs font-medium">
                      {service.title.split(" ")[0]}
                    </span>
                  </Button>
                </motion.div>
              );
            })}
          </motion.div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center">
            <div className="w-1 h-3 bg-white/70 rounded-full mt-2" />
          </div>
        </motion.div>
      </section>

      {/* Services Section with Parallax Cards */}
      <section id="services" className="py-20 bg-[#F3F3F3]">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-5xl md:text-6xl text-[#1A1B2E] mb-6 font-bold">
              Our Services
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              From concept to creation, we handle every aspect
              of your video production needs
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <motion.div
                  key={service.id}
                  initial={{ opacity: 0, y: 100 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  transition={{
                    delay: index * 0.3,
                    duration: 0.8,
                    ease: "easeOut",
                  }}
                  whileHover={{ y: -15, scale: 1.02 }}
                  className="group cursor-pointer"
                >
                  <Card className="relative h-80 bg-white border-0 shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden rounded-2xl">
                    {/* Background Image */}
                    <div className="absolute inset-0">
                      <ImageWithFallback
                        src={service.backgroundImage}
                        alt={service.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      />
                      <div
                        className="absolute inset-0"
                        style={{
                          background:
                            "linear-gradient(to top, rgba(26, 27, 46, 0.9) 0%, rgba(58, 12, 163, 0.5) 50%, transparent 100%)",
                        }}
                      />
                    </div>

                    {/* Content */}
                    <div className="relative z-10 p-8 h-full flex flex-col justify-end">
                      <div className="flex items-center gap-4 mb-4">
                        <div
                          className="w-16 h-16 backdrop-blur-sm rounded-xl flex items-center justify-center group-hover:scale-110 transition-all duration-300"
                          style={{
                            background:
                              "linear-gradient(135deg, rgba(114, 9, 183, 0.3) 0%, rgba(72, 149, 239, 0.3) 100%)",
                            border:
                              "1px solid rgba(255, 255, 255, 0.2)",
                          }}
                        >
                          <Icon
                            className="w-8 h-8"
                            style={{ color: "#4895EF" }}
                          />
                        </div>
                        <div>
                          <h3 className="text-2xl font-bold text-white mb-1">
                            {service.title}
                          </h3>
                          <span className="text-3xl">
                            {service.emoji}
                          </span>
                        </div>
                      </div>

                      <p className="text-white/90 mb-6 text-lg leading-relaxed">
                        {service.fullDescription}
                      </p>

                      <div className="flex flex-wrap gap-2">
                        {service.features
                          .slice(0, 2)
                          .map((feature, i) => (
                            <span
                              key={i}
                              className="px-3 py-1 backdrop-blur-sm text-white text-sm rounded-full font-medium border"
                              style={{
                                background:
                                  "linear-gradient(135deg, rgba(114, 9, 183, 0.2) 0%, rgba(72, 149, 239, 0.2) 100%)",
                                borderColor:
                                  "rgba(255, 255, 255, 0.3)",
                              }}
                            >
                              {feature}
                            </span>
                          ))}
                      </div>

                      {/* Hover Overlay */}
                      <motion.div
                        className="absolute inset-0 backdrop-blur-[1px] opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center"
                        style={{
                          background:
                            "linear-gradient(135deg, rgba(58, 12, 163, 0.15) 0%, rgba(67, 97, 238, 0.15) 100%)",
                        }}
                        initial={{ opacity: 0 }}
                        whileHover={{ opacity: 1 }}
                      >
                        <div className="text-center">
                          <Eye className="w-12 h-12 text-white mx-auto mb-4" />
                          <p className="text-white font-semibold text-lg">
                            View Portfolio
                          </p>
                        </div>
                      </motion.div>
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Portfolio Showcase */}
      <section id="portfolio" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-5xl md:text-6xl text-[#1A1B2E] mb-6 font-bold">
              Our Work
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              See how we've transformed bold ideas into viral
              content for brands across industries
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, serviceIndex) => (
              <Dialog key={service.id}>
                <DialogTrigger asChild>
                  <motion.div
                    className="group cursor-pointer"
                    initial={{ opacity: 0, y: 50 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{
                      delay: serviceIndex * 0.1,
                      duration: 0.6,
                    }}
                    whileHover={{ y: -10 }}
                  >
                    <Card className="relative h-64 overflow-hidden rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 border-0">
                      <ImageWithFallback
                        src={service.portfolioItems[0]}
                        alt={`${service.title} portfolio`}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                      <div
                        className="absolute inset-0"
                        style={{
                          background:
                            "linear-gradient(to top, rgba(26, 27, 46, 0.8) 0%, transparent 60%)",
                        }}
                      />
                      <div className="absolute bottom-0 left-0 right-0 p-6">
                        <div className="flex items-center gap-3 mb-2">
                          <service.icon className="w-6 h-6 text-[#4895EF]" />
                          <span className="text-white font-semibold">
                            {service.title}
                          </span>
                        </div>
                        <p className="text-white/80 text-sm">
                          {service.portfolioItems.length}{" "}
                          projects
                        </p>
                      </div>
                      <div
                        className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center"
                        style={{
                          background:
                            "linear-gradient(135deg, rgba(58, 12, 163, 0.2) 0%, rgba(67, 97, 238, 0.2) 100%)",
                        }}
                      >
                        <Play className="w-12 h-12 text-white" />
                      </div>
                    </Card>
                  </motion.div>
                </DialogTrigger>
                <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto border-0 bg-[#1A1B2E]">
                  <div className="p-8">
                    <div className="flex items-center gap-4 mb-8">
                      <service.icon className="w-10 h-10 text-[#4895EF]" />
                      <h3 className="text-4xl font-bold text-white">
                        {service.title} Portfolio
                      </h3>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {service.portfolioItems.map((item, i) => (
                        <motion.div
                          key={i}
                          className="relative group cursor-pointer overflow-hidden rounded-xl"
                          whileHover={{ scale: 1.05 }}
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: i * 0.1 }}
                        >
                          <ImageWithFallback
                            src={item}
                            alt={`${service.title} example ${i + 1}`}
                            className="w-full h-64 object-cover"
                          />
                          <div
                            className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center"
                            style={{
                              background:
                                "linear-gradient(135deg, rgba(58, 12, 163, 0.3) 0%, rgba(67, 97, 238, 0.3) 100%)",
                            }}
                          >
                            <Play className="w-8 h-8 text-white" />
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 bg-[#F3F3F3]">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-5xl md:text-6xl text-[#1A1B2E] mb-6 font-bold">
              Why Choose Us
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              We deliver exceptional results through creativity,
              speed, and unmatched value
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {whyChooseUs.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{
                    delay: index * 0.2,
                    duration: 0.8,
                  }}
                  whileHover={{ y: -10, scale: 1.02 }}
                  className="group"
                >
                  <Card className="p-8 h-full bg-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 text-center rounded-2xl">
                    <div
                      className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-all duration-300"
                      style={{
                        background:
                          "linear-gradient(135deg, rgba(58, 12, 163, 0.1) 0%, rgba(72, 149, 239, 0.1) 100%)",
                        border:
                          "2px solid rgba(114, 9, 183, 0.2)",
                      }}
                    >
                      <Icon className="w-8 h-8 text-[#3A0CA3]" />
                    </div>
                    <h3 className="text-xl font-bold text-[#1A1B2E] mb-4">
                      {benefit.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed">
                      {benefit.description}
                    </p>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-5xl md:text-6xl text-[#1A1B2E] mb-6 font-bold">
              Let's Create Your Next Viral Ad
            </h2>
            <p className="text-xl text-gray-600">
              Tell us about your vision and we'll make it
              reality within days, not weeks
            </p>
          </motion.div>

          <motion.div
            className="grid grid-cols-1 lg:grid-cols-2 gap-12"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2, duration: 0.8 }}
          >
            {/* Contact Form */}
            <Card className="p-8 shadow-lg border-0 rounded-2xl">
              <form className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[#1A1B2E] mb-2 font-medium">
                      First Name
                    </label>
                    <Input
                      className="rounded-lg h-12 border-gray-300 focus:ring-2 focus:ring-[#4361EE] focus:border-[#3A0CA3] transition-all duration-300"
                      style={{
                        "&:focus": {
                          borderImage:
                            "linear-gradient(135deg, #3A0CA3, #4361EE) 1",
                        },
                      }}
                    />
                  </div>
                  <div>
                    <label className="block text-[#1A1B2E] mb-2 font-medium">
                      Last Name
                    </label>
                    <Input className="rounded-lg h-12 border-gray-300 focus:ring-2 focus:ring-[#4361EE] focus:border-[#3A0CA3] transition-all duration-300" />
                  </div>
                </div>
                <div>
                  <label className="block text-[#1A1B2E] mb-2 font-medium">
                    Email
                  </label>
                  <Input
                    type="email"
                    className="rounded-lg h-12 border-gray-300 focus:ring-2 focus:ring-[#4361EE] focus:border-[#3A0CA3] transition-all duration-300"
                  />
                </div>
                <div>
                  <label className="block text-[#1A1B2E] mb-2 font-medium">
                    Project Type
                  </label>
                  <select className="w-full h-12 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#4361EE] focus:border-[#3A0CA3] transition-all duration-300">
                    <option>Mobile Videography</option>
                    <option>Creative Scriptwriting</option>
                    <option>Video Editing</option>
                    <option>Full Production</option>
                    <option>Multiple Services</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[#1A1B2E] mb-2 font-medium">
                    Tell us about your vision
                  </label>
                  <Textarea
                    rows={4}
                    className="rounded-lg border-gray-300 focus:ring-2 focus:ring-[#4361EE] focus:border-[#3A0CA3] transition-all duration-300"
                    placeholder="What's your bold idea? What kind of impact do you want to make?"
                  />
                </div>
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button
                    className="w-full py-4 rounded-full font-semibold text-lg text-white shadow-lg hover:shadow-xl transition-all duration-300"
                    style={{
                      background:
                        "linear-gradient(135deg, #3A0CA3 0%, #4361EE 100%)",
                      "&:hover": {
                        background:
                          "linear-gradient(135deg, #3A0CA3 0%, #4361EE 80%)",
                      },
                    }}
                  >
                    Let's Make It Viral
                  </Button>
                </motion.div>
              </form>
            </Card>

            {/* Contact Info */}
            <div className="space-y-8">
              <Card
                className="p-6 shadow-lg border-0 rounded-2xl"
                style={{
                  background:
                    "linear-gradient(135deg, rgba(58, 12, 163, 0.05) 0%, rgba(67, 97, 238, 0.05) 100%)",
                }}
              >
                <div className="flex items-center gap-4">
                  <div
                    className="w-14 h-14 rounded-full flex items-center justify-center"
                    style={{
                      background:
                        "linear-gradient(135deg, #3A0CA3 0%, #4361EE 100%)",
                    }}
                  >
                    <Mail className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-[#1A1B2E] mb-1">
                      Email Us
                    </h4>
                    <p className="text-gray-600 text-lg">
                      hello@awes0meagency.com
                    </p>
                  </div>
                </div>
              </Card>

              <Card
                className="p-6 shadow-lg border-0 rounded-2xl"
                style={{
                  background:
                    "linear-gradient(135deg, rgba(58, 12, 163, 0.05) 0%, rgba(67, 97, 238, 0.05) 100%)",
                }}
              >
                <div className="flex items-center gap-4">
                  <div
                    className="w-14 h-14 rounded-full flex items-center justify-center"
                    style={{
                      background:
                        "linear-gradient(135deg, #3A0CA3 0%, #4361EE 100%)",
                    }}
                  >
                    <Phone className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-[#1A1B2E] mb-1">
                      Call Us
                    </h4>
                    <p className="text-gray-600 text-lg">
                      +1 (555) 123-4567
                    </p>
                  </div>
                </div>
              </Card>

              <div className="pt-8">
                <h4 className="text-xl font-bold text-[#1A1B2E] mb-6">
                  Follow Our Journey
                </h4>
                <div className="flex gap-4">
                  {[Instagram, Twitter, Linkedin].map(
                    (Icon, i) => (
                      <motion.a
                        key={i}
                        href="#"
                        className="w-14 h-14 bg-[#F3F3F3] rounded-full flex items-center justify-center text-gray-600 transition-all duration-300 border-2 border-transparent"
                        style={{
                          "&:hover": {
                            background:
                              "linear-gradient(135deg, #3A0CA3 0%, #4361EE 100%)",
                            color: "white",
                          },
                        }}
                        whileHover={{
                          scale: 1.1,
                          y: -2,
                          background:
                            "linear-gradient(135deg, #3A0CA3 0%, #4361EE 100%)",
                        }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <Icon className="w-6 h-6" />
                      </motion.a>
                    ),
                  )}
                </div>
              </div>

              <div
                className="p-6 rounded-2xl"
                style={{
                  background:
                    "linear-gradient(135deg, rgba(58, 12, 163, 0.1) 0%, rgba(67, 97, 238, 0.1) 100%)",
                }}
              >
                <div className="flex items-start gap-4">
                  <CheckCircle className="w-6 h-6 text-[#3A0CA3] mt-1 flex-shrink-0" />
                  <div>
                    <p className="text-[#1A1B2E] font-semibold mb-2">
                      Quick Response Guarantee
                    </p>
                    <p className="text-gray-600">
                      We'll get back to you within 4 hours on
                      business days with a detailed project
                      proposal.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer
        className="py-12 text-center"
        style={{
          background:
            "linear-gradient(135deg, #3A0CA3 0%, #4361EE 100%)",
        }}
      >
        <div className="max-w-4xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="flex justify-center mb-6">
              <img
                src={logo}
                alt="AWES0ME AGENCY"
                className="w-16 h-16 opacity-90 rounded-lg"
              />
            </div>
            <p className="text-white/80 text-lg">
              © 2024 AWES0ME AGENCY. All rights reserved.
            </p>
            <p className="text-white font-medium mt-2">
              Making bold ideas visually stunning since day one.
            </p>
          </motion.div>
        </div>
      </footer>
    </div>
  );
}